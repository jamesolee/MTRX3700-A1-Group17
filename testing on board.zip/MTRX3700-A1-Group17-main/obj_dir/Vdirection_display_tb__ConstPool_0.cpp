// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Constant pool
//

#include "verilated.h"

extern const VlUnpacked<CData/*6:0*/, 8> Vdirection_display_tb__ConstPool__TABLE_h549c705c_0 = {{
    0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x2fU
}};

extern const VlUnpacked<CData/*6:0*/, 8> Vdirection_display_tb__ConstPool__TABLE_h70951755_0 = {{
    0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x47U, 0x7fU, 0x7fU
}};

extern const VlUnpacked<CData/*6:0*/, 8> Vdirection_display_tb__ConstPool__TABLE_hb923c2b3_0 = {{
    0x7fU, 0x7fU, 0x7fU, 0x03U, 0x7fU, 0x7fU, 0x7fU, 0x7fU
}};

extern const VlUnpacked<CData/*6:0*/, 8> Vdirection_display_tb__ConstPool__TABLE_hfb984b4f_0 = {{
    0x7fU, 0x0eU, 0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x7fU, 0x7fU
}};
